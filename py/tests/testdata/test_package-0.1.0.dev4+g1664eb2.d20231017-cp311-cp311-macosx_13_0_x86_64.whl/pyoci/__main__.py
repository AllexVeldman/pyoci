import json
from pathlib import Path

from pyoci.client import Client
from pyoci.descriptor import EmptyConfig
from pyoci.layer import create_file_layer
from pyoci.manifest import Manifest

ARTIFACT_TYPE = "application/pyoci.package.v1"


def run():
    # image_path = Path("out")
    # rmtree(image_path, ignore_errors=True)
    #
    # image_path.mkdir(parents=True, exist_ok=True)

    name = "test"
    tag = "latest"

    manifest = Manifest(
        artifactType=ARTIFACT_TYPE,
        config=EmptyConfig,
    )

    with Client("http://localhost:5000") as client:
        client.push_blob(name=name, blob=b"{}", digest=EmptyConfig.digest)

        manifest.layers.append(
            create_file_layer(
                Path("test") / "some_module.py",
                name="test",
                artifact_type=ARTIFACT_TYPE,
                client=client,
            )
        )
        client.push_manifest(name=name, reference=tag, manifest=manifest)


def oci_layout(image_path):
    (image_path / "oci-layout").write_text(json.dumps({"imageLayoutVersion": "1.0.0"}))


if __name__ == "__main__":
    run()
